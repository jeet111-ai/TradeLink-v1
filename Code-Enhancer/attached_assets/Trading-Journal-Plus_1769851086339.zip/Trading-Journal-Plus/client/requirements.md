## Packages
recharts | For financial charts (P&L, allocation)
date-fns | For date formatting and manipulation

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
  mono: ["var(--font-mono)"],
}
